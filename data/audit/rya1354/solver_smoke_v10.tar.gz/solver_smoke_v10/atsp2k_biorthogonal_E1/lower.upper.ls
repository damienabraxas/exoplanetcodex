  Transition between files: 
  lower                   
  upper                   

 Z =   8 n =  3
   4  -74.52991600  2p(3)4S3.3s_5S                                    
   6  -74.47525550  2p(3)4S3.3p_5P                                    
   11996.18 CM-1      8335.99 ANGS(VAC)      8335.12 ANGS(AIR)
 E1  length:   S =  1.36014D+02   GF =  4.95623D+00   AKI =  3.17167D+07
    velocity:  S =  1.31920D+02   GF =  4.80704D+00   AKI =  3.07621D+07
