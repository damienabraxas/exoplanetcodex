 Transition between files:
 f1 = lower
 f2 = upper


 Magnetic 2**( 1)-pole transitions
 =================================

 Upper       Lower 
 Lev  J P   Lev  J P       E (Kays)         A (s-1)          gf            S
 f1  1    2 -  f2  1    1 -        3325.93 M  1.70116D-08  1.15278D-14  8.57117D-08


 Electric 2**( 2)-pole transitions
 =================================

 Upper       Lower 
 Lev  J P   Lev  J P       E (Kays)         A (s-1)          gf            S
 f1  1    2 -  f2  1    1 -        3325.93 C  1.06672D-14  7.22854D-21  1.17019D-09
                                           B  1.32862D-16  9.00331D-23  1.45749D-11


 Magnetic 2**( 3)-pole transitions
 =================================

 Upper       Lower 
 Lev  J P   Lev  J P       E (Kays)         A (s-1)          gf            S
 f1  1    2 -  f2  1    1 -        3325.93 M  1.63304D-26  1.10662D-32  4.33276D-07
