 Transition between files:
 f1 = lower
 f2 = upper


 Magnetic 2**( 1)-pole transitions
 =================================

 Upper       Lower 
 Lev  J P   Lev  J P       E (Kays)         A (s-1)          gf            S
 f2  1    1 -  f1  1    2 -        2755.01 M  1.66310D-08  9.85486D-15  8.84569D-08


 Electric 2**( 2)-pole transitions
 =================================

 Upper       Lower 
 Lev  J P   Lev  J P       E (Kays)         A (s-1)          gf            S
 f2  1    1 -  f1  1    2 -        2755.01 C  6.12851D-17  3.63151D-23  1.03433D-11
                                           B  2.23866D-16  1.32654D-22  3.77827D-11


 Magnetic 2**( 3)-pole transitions
 =================================

 Upper       Lower 
 Lev  J P   Lev  J P       E (Kays)         A (s-1)          gf            S
 f2  1    1 -  f1  1    2 -        2755.01 M  1.19289D-26  7.06856D-33  7.09650D-07
