program component_control
use orb_C, only: NW, NP, NH
implicit none
integer :: indices(4), count, i
NW=4
NP(1:4)=[2,2,2,3]
NH(1:4)=[character(len=2) :: 's ', 'p-', 'p ', 's ']
do i=1,3
  call GETRSL(indices,count)
  write(*,'(*(I0,1X))') count,indices(1:count)
end do
end program component_control
