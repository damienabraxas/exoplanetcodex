"""Independent LS MCHF check of the dominant 3s3S -> 2p4 3P E1 decay.

This is a partial E1 rate, not a certified complete relativistic lifetime.
Use native HF seeds, modern GENCL/nonh/MCHF/biotr, no empirical adjustments.
"""
import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import platform
import shutil

from rya1354_solver_smoke import run,sha


def configuration(term,n):
    reference='2p(4)' if term=='3P' else '2p(3)3s(1)'
    last=1 if term=='3P' else 2
    virtual=['2p']+[f'{k}{l}' for k in range(3,n+1) for l in 'spdfg'[:k]]
    return f'\nO_{term}\n 1s 2s\n{reference}\n\n\nsd\n{",".join(virtual)}\n1\n{last}\n{term}\n\n'


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--atsp',type=Path,required=True)
    ap.add_argument('--book-bin',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--n-max',type=int,choices=(3,4,5),default=5)
    ap.add_argument('--strict-bin',type=Path)
    args=ap.parse_args()
    if platform.node().lower().split('.')[0]!='sirius':
        raise RuntimeError('Atomic solvers belong on Sirius')
    args.atsp=args.atsp.resolve()
    args.book_bin=args.book_bin.resolve()
    if args.strict_bin:
        args.strict_bin=args.strict_bin.resolve()
    args.out.mkdir(parents=True,exist_ok=False)
    shutil.copyfile(__file__,args.out/'driver.py')
    receipt=dict(schema='rya1354.lifetime-mchf.v1',status='RUNNING',scientific_admission='HOLD',
                 started_utc=datetime.now(timezone.utc).isoformat(),steps=[],
                 scope='Nonrelativistic LS summed E1 to ground3P only, not full13-channel relativistic lifetime; valence SD/frozen1s2s and older layers; no observed energies/gf fitted')
    try:
        previous={}
        for term,reference in [('3P','2p(4)'),('3S','2p(3)3s(1)')]:
            out=args.out/('reference_'+term)
            out.mkdir()
            receipt['steps'].append(run(args.book_bin/'HF',f'O,{term},8.\n  1s  2s\n{reference}\nall\ny\ny\nn\nn\n',out,600))
            hf=(out/'HF.stdout').read_text()+(out/'HF.stderr').read_text()
            if not (out/'wfn.out').is_file() or 'UNABLE TO SOLVE EQUATION' in hf or 'NaN' in hf:
                raise ValueError('Native HF seed failed despite possible zero exit')
            previous[term]=out/'wfn.out'
        for n in range(3,args.n_max+1):
            states={}
            for term,parity in [('3P','e'),('3S','o')]:
                out=args.out/f'n{n}_{term}'
                out.mkdir()
                receipt['steps'].append(run(args.atsp/'bin/gencl',configuration(term,n),out,600))
                receipt['steps'].append(run(args.atsp/'bin/nonh','',out,600))
                shutil.copyfile(previous[term],out/'wfn.inp')
                varied=','.join(f'{n}{l}' for l in 'spdfg'[:n])
                spec=('1s 2s 2p'+(' 3s' if term=='3S' else '')) if n==3 else ''
                controls=f'{term},8.\n1,1\n{varied}\n{spec}\ny\nn\ny\nn\n.f.,1.e-9,1.e-9\nn\n500,0\ny\n'
                receipt['steps'].append(run((args.strict_bin or args.atsp/'bin')/'mchf',controls,out,7200))
                if args.strict_bin and 'RYA1354_ORBITAL_STOP' not in (out/'mchf.stdout').read_text():
                    raise ValueError('MCHF orbital criterion not established')
                for src,dst in [('cfg.inp','state.c'),('wfn.out','state.w'),(term+parity+'.l','state.l')]:
                    shutil.copyfile(out/src,out/dst)
                previous[term]=out/'wfn.out'
                states[term]=out
            transition=args.out/f'n{n}_E1'
            transition.mkdir()
            for tag,term in [('lower','3P'),('upper','3S')]:
                for ext in ('c','w','l'):
                    shutil.copyfile(states[term]/('state.'+ext),transition/(tag+'.'+ext))
            receipt['steps'].append(run(args.atsp/'bin/biotr','lower\nupper\nn\nn\nc\nE1\n*\n',transition,1800))
            if not (transition/'lower.upper.ls').is_file() or any(s['semantic_errors'] for s in receipt['steps']):
                raise ValueError('Native LS transition refused or absent')
            receipt['last_completed_layer']=n
        receipt['status']='LS_DOMINANT_E1_SEQUENCE_COMPLETED_REVIEW_REQUIRED'
    except Exception as exc:
        receipt.update(status='FAILED_RETAINED',error=f'{type(exc).__name__}: {exc}')
        raise
    finally:
        receipt['files']={str(p.relative_to(args.out)):dict(sha256=sha(p),bytes=p.stat().st_size)
                          for p in sorted(args.out.rglob('*')) if p.is_file()}
        (args.out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')


if __name__=='__main__':
    main()
