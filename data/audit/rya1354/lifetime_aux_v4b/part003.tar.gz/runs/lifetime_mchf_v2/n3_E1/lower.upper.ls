  Transition between files: 
  lower                   
  upper                   

 Z =   8 n =  3
   4  -74.87695219  2p(4)_3P2                                         
   2  -74.54506765  2p(3)4S3.3s_3S                                    
   72837.74 CM-1      1372.91 ANGS(VAC)      1372.91 ANGS(AIR)
 E1  length:   S =  1.21897D+00   GF =  2.69695D-01   AKI =  3.18132D+08
    velocity:  S =  1.91154D+00   GF =  4.22926D-01   AKI =  4.98883D+08
