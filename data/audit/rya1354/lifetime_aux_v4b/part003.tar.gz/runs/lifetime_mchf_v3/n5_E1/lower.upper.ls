  Transition between files: 
  lower                   
  upper                   

 Z =   8 n =  5
   4  -74.89310566  2p(4)_3P2                                         
   2  -74.55072682  2p(3)4S3.3s_3S                                    
   75140.89 CM-1      1330.83 ANGS(VAC)      1330.83 ANGS(AIR)
 E1  length:   S =  1.54669D+00   GF =  3.53024D-01   AKI =  4.43178D+08
    velocity:  S =  1.63672D+00   GF =  3.73573D-01   AKI =  4.68975D+08
