  Transition between files: 
  lower                   
  upper                   

 Z =   8 n =  3
   4  -73.76810848  2p(4)_3P2                                         
   2  -73.40914253  2p(3)4S3.3s_3S                                    
   78781.21 CM-1      1269.34 ANGS(VAC)      1269.34 ANGS(AIR)
 E1  length:   S =  9.21919D-01   GF =  2.20617D-01   AKI =  3.04443D+08
    velocity:  S =  1.30032D+00   GF =  3.11169D-01   AKI =  4.29401D+08
