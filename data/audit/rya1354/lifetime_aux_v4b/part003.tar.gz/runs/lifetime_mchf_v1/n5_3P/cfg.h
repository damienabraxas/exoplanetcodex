   2 Closed Shells:
  1s  2s
  13 Other Orbitals:
  2p  3p  4p  4f  5p  5f  3s  3d  4s  4d  5s  5d  5g
  1    5106   30000   snonh
  3Pe   202     10498          30039       195
