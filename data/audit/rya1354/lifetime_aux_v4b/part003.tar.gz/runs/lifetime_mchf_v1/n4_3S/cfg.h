   2 Closed Shells:
  1s  2s
   8 Other Orbitals:
  2p  3s  3p  3d  4s  4p  4d  4f
  1     794   30000   snonh
  3So    46       706           2519        41
