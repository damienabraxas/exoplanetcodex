   2 Closed Shells:
  1s  2s
  13 Other Orbitals:
  2p  3s  3p  3d  4s  4p  4d  5s  5p  4f  5d  5f  5g
  1    4876   30000   snonh
  3So   114      3555          11591        99
