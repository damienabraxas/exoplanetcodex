   2 Closed Shells:
  1s  2s
   4 Other Orbitals:
  2p  3s  3p  3d
  1      73   30000   snonh
  3So    11        57            260        10
