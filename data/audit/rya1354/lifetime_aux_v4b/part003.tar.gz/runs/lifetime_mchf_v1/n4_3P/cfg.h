   2 Closed Shells:
  1s  2s
   8 Other Orbitals:
  2p  3p  4p  4f  3s  3d  4s  4d
  1     839   30000   snonh
  3Pe    79      1758           5256        75
