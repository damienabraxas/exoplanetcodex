  Transition between files: 
  lower                   
  upper                   

 Z =   8 n =  5
   4  -73.81664839  2p(4)_3P2                                         
   2  -73.42429093  2p(3)4S3.3s_3S                                    
   86109.55 CM-1      1161.31 ANGS(VAC)      1161.31 ANGS(AIR)
 E1  length:   S =  1.34316D+00   GF =  3.51320D-01   AKI =  5.79197D+08
    velocity:  S =  1.18371D+00   GF =  3.09615D-01   AKI =  5.10441D+08
