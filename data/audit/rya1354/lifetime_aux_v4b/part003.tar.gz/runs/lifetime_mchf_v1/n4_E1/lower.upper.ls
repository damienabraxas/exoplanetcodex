  Transition between files: 
  lower                   
  upper                   

 Z =   8 n =  4
   4  -73.81261387  2p(4)_3P2                                         
   2  -73.42270421  2p(3)4S3.3s_3S                                    
   85572.34 CM-1      1168.60 ANGS(VAC)      1168.60 ANGS(AIR)
 E1  length:   S =  1.33772D+00   GF =  3.47715D-01   AKI =  5.66123D+08
    velocity:  S =  1.20664D+00   GF =  3.13644D-01   AKI =  5.10652D+08
