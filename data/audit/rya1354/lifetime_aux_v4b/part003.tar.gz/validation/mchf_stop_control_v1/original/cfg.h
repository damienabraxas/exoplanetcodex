   3 Closed Shells:
  1s  2s  2p
   7 Other Orbitals:
  3s  3p  3d  4s  4p  4d  4f
  1     462   30000   snonh
  1De   234     12400          40419       145
