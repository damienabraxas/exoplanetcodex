"""Independent lossless capsule replay of first 4s/4p CI; metadata only."""
import hashlib
import json
from pathlib import Path
import tempfile
from rya1354_native_parts import load_parts
from rya1354_fac_potential_audit import verify_directory
from rya1354_fac_radial_ci import review
from rya1354_fac_potential_fields import layout


def summarize(base):
    directory=base/'fac_radial_ci_first_complete_v33';verify_directory(directory);files,_=load_parts(directory)
    root='runs/fac_radial_ci_first_v33/';r=json.loads(files[root+'receipt.json'])
    parent,_=load_parts(base/'fac_full_valence_complete_v28');old='runs/fac_full_valence_v28/';pr=json.loads(parent[old+'receipt.json'])
    preflight,_=load_parts(base/'fac_radial_preflight_complete_v32');pfr='runs/fac_radial_preflight_v32/'
    if r['status']!='FAC_RADIAL_CI_FIRST_CASE_COMPLETED_REVIEW_REQUIRED' or r['baseline_receipt_sha256']!=hashlib.sha256(parent[old+'receipt.json']).hexdigest() or r['preflight_receipt_sha256']!=hashlib.sha256(preflight[pfr+'receipt.json']).hexdigest() or r['probe']!=pr['probe']:raise ValueError('CI provenance or terminal status differs')
    if set(r['cases'])!={'ground_coherent10'}:raise ValueError('CI case scope differs')
    spec=layout(files[root+'source_documents/faclib/radial.c'].decode(),files[root+'source_documents/faclib/orbital.c'].decode(),files[root+'source_documents/faclib/consts.h'].decode())
    if spec!=r['potential_layout']:raise ValueError('Source-derived potential layout differs')
    prefix=root+'ground_coherent10/'
    if files[prefix+'source.pot']!=parent[old+'ground_coherent10/o.pot'] or files[prefix+'source.pot']!=preflight[pfr+'ground_coherent10/source.pot']:raise ValueError('Paired potential differs')
    # Write verified basenames only; replay comparison is streaming and runs no solver.
    with tempfile.TemporaryDirectory(prefix='rya1354-ci-metadata-') as temp:
        out=Path(temp)
        for path,data in files.items():
            if path.startswith(prefix):
                name=path.removeprefix(prefix)
                if Path(name).name!=name:raise ValueError('Unexpected nested case evidence')
                (out/name).write_bytes(data)
        result=review(out,spec)
    if result!=r['cases']['ground_coherent10']:raise ValueError('CI archived replay differs from native receipt')
    return dict(schema='rya1354.fac-radial-ci-audit.v33',scientific_admission='HOLD',exposure='EXPOSED_NONBLIND',adoption_allowed=False,accepted_lifetime=None,uncertainty=None,covariance=None,calibrated_sigma=None,cases={'ground_coherent10':result})

if __name__=='__main__':print(json.dumps(summarize(Path(__file__).resolve().parents[1]/'data/audit/rya1354'),indent=2))
