 Transition between files:
 f1 = lower
 f2 = upper


 Magnetic 2**( 1)-pole transitions
 =================================

 Upper       Lower 
 Lev  J P   Lev  J P       E (Kays)         A (s-1)          gf            S
 f2  1    1 -  f1  1    2 -        3076.26 M  2.41225D-08  1.14645D-14  9.21591D-08


 Electric 2**( 2)-pole transitions
 =================================

 Upper       Lower 
 Lev  J P   Lev  J P       E (Kays)         A (s-1)          gf            S
 f2  1    1 -  f1  1    2 -        3076.26 C  4.64642D-14  2.20827D-20  4.51780D-09
                                           B  3.67642D-16  1.74726D-22  3.57465D-11


 Magnetic 2**( 3)-pole transitions
 =================================

 Upper       Lower 
 Lev  J P   Lev  J P       E (Kays)         A (s-1)          gf            S
 f2  1    1 -  f1  1    2 -        3076.26 M  2.48415D-26  1.18062D-32  6.82854D-07
