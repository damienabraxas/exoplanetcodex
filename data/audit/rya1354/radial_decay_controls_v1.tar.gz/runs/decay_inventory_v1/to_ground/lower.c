Core subshells:

Peel subshells:
  1s   2s   2p-  2p
CSF(s):
  1s ( 2)  2s ( 2)  2p ( 4)

                           0+
  1s ( 2)  2s ( 2)  2p-( 2)  2p ( 2)
                                   0
                                    0+
 *
  1s ( 2)  2s ( 2)  2p-( 1)  2p ( 3)
                        1/2      3/2
                                    1+
 *
  1s ( 2)  2s ( 2)  2p-( 1)  2p ( 3)
                        1/2      3/2
                                    2+
  1s ( 2)  2s ( 2)  2p-( 2)  2p ( 2)
                                   2
                                    2+
