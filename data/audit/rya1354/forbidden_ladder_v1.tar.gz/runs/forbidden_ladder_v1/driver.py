"""Ground-configuration VV-SD convergence with native M1/E2/M3/E4 operators.

All five lowest 2p4 levels share an EOL orbital set. Fixed n<3 radial functions
start from coverage_v8 ground HF; optimize new layers only. No observed energies
or transition strengths enter the optimization. Same-file duplicate directions
must not be summed. This is not a certified forbidden-line data product.
"""
import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import platform
import re
import shutil
from rya1354_solver_smoke import run,sha


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--grasp-bin',type=Path,required=True)
    ap.add_argument('--seed',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--n-max',type=int,choices=(3,4,5),default=5)
    args=ap.parse_args()
    if platform.node().lower().split('.')[0]!='sirius':
        raise RuntimeError('Solver calculations belong on Sirius')
    args.grasp_bin=args.grasp_bin.resolve()
    args.out.mkdir(parents=True,exist_ok=False)
    shutil.copyfile(Path(__file__),args.out/'driver.py')
    receipt=dict(schema='rya1354.forbidden-vv-sd.v1',status='RUNNING',scientific_admission='HOLD',
                 started_utc=datetime.now(timezone.utc).isoformat(),steps=[],
                 model='Point static Z8, Dirac-Coulomb; closed 1s2/2s2 occupations and fixed n<3 radial functions; valence SD; EOL five ground-configuration levels; new-layer optimization; no observed-level substitution')
    try:
        for n in range(3,args.n_max+1):
            out=args.out/f'n{n}_ground'
            out.mkdir()
            active=','.join(f'{n}{l}' for l in 'spdfg'[:n])
            for exe,stdin in [('rnucleus','8\n0\n0\n0\n0\n0\n'),
                              ('rcsfgenerate',f'*\n0\n1s(2,i)2s(2,i)2p(4,*)\n\n{active}\n0,4\n2\nn\n')]:
                receipt['steps'].append(run(args.grasp_bin/exe,stdin,out,600))
            shutil.copyfile(out/'rcsf.out',out/'rcsf.inp')
            previous=args.seed/'state.w' if n==3 else args.out/f'n{n-1}_ground'/'state.w'
            shutil.copyfile(previous,out/'previous.w')
            for exe,stdin in [('rangular','y\n'),('rwfnestimate','y\n1\nprevious.w\n*\n3\n*\n'),
                              ('rmcdhf',f'y\n1,2\n1\n1,2\n5\n{n}*\n\n100\n')]:
                receipt['steps'].append(run(args.grasp_bin/exe,stdin,out,3600))
            for src,ext in [('rcsf.inp','c'),('rwfn.out','w'),('rmix.out','m')]:
                shutil.copyfile(out/src,out/f'state.{ext}')
            receipt['steps'].append(run(args.grasp_bin/'jj2lsj','state\nn\nn\ny\n',out,600))
            # Leading labels, not wavelength proximity, identify the five ASFs.
            blocks=re.findall(r'^\s*\d+\s+(\d+)\s+([+-])\s+[^\n]+\n([^\n]+)',
                              (out/'state.lsj.lbl').read_text(),re.M)
            expected=[('0','3P'),('0','1S'),('1','3P'),('2','3P'),('2','1D')]
            if len(blocks)!=5 or any(j!=ej or p!='+' or '2p(4)' not in line or not line.rstrip().endswith('_'+term)
                                     for (j,p,line),(ej,term) in zip(blocks,expected)):
                raise ValueError('Configured five-level identity inventory not established')
            transition=args.out/f'n{n}_multipoles'
            transition.mkdir()
            for tag in ('lower','upper'):
                for ext in ('c','w','m'):
                    shutil.copyfile(out/f'state.{ext}',transition/f'{tag}.{ext}')
            shutil.copyfile(out/'isodata',transition/'isodata')
            for exe,stdin in [('rbiotransform','y\nn\nlower\nupper\ny\n'),
                              ('rtransition','y\nn\nlower\nupper\nM1,E2,M3,E4\nn\nn\n')]:
                receipt['steps'].append(run(args.grasp_bin/exe,stdin,transition,1800))
            if not (transition/'lower.upper.t').is_file() or any(s['semantic_errors'] for s in receipt['steps']):
                raise ValueError('Native multipole result missing or input refused')
        receipt['status']='FORBIDDEN_MODEL_LADDER_COMPLETED_REVIEW_REQUIRED'
    except Exception as exc:
        receipt.update(status='FAILED_RETAINED',error=f'{type(exc).__name__}: {exc}')
        raise
    finally:
        receipt['files']={str(p.relative_to(args.out)):{'sha256':sha(p),'bytes':p.stat().st_size}
                          for p in sorted(args.out.rglob('*')) if p.is_file()}
        (args.out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')


if __name__=='__main__':
    main()
