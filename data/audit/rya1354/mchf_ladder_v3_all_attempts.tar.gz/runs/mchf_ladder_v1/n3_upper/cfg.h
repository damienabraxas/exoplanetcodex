   2 Closed Shells:
  1s  2s
   4 Other Orbitals:
  2p  3p  3s  3d
  1      76   30000   snonh
  5Pe    11        52            302         8
