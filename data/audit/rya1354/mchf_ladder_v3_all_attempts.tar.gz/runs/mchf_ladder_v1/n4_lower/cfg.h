   2 Closed Shells:
  1s  2s
   8 Other Orbitals:
  2p  3s  3p  4s  3d  4p  4d  4f
  1     792   30000   snonh
  5So    19       153            727        19
