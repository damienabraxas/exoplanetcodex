  Transition between files: 
  lower                   
  upper                   

 Z =   8 n =  4
   4  -74.56190721  2p(3)4S3.3s_5S                                    
   6  -74.50386518  2p(3)4S3.3p_5P                                    
   12738.32 CM-1      7850.33 ANGS(VAC)      7849.52 ANGS(AIR)
 E1  length:   S =  1.31441D+02   GF =  5.08589D+00   AKI =  3.66980D+07
    velocity:  S =  1.21240D+02   GF =  4.69117D+00   AKI =  3.38498D+07
