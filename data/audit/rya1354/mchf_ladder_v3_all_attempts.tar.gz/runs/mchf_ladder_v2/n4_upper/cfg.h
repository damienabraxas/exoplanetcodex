   2 Closed Shells:
  1s  2s
   8 Other Orbitals:
  2p  3s  3p  4p  4f  3d  4s  4d
  1     815   30000   snonh
  5Pe    59       955           4378        52
