  Transition between files: 
  lower                   
  upper                   

 Z =   8 n =  3
   4  -74.55688507  2p(3)4S3.3s_5S                                    
   6  -74.49090901  2p(3)4S3.3p_5P                                    
   14479.57 CM-1      6906.28 ANGS(VAC)      6905.56 ANGS(AIR)
 E1  length:   S =  1.33467D+02   GF =  5.87023D+00   AKI =  5.47291D+07
    velocity:  S =  7.95149D+01   GF =  3.49727D+00   AKI =  3.26055D+07
