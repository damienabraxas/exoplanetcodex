   2 Closed Shells:
  1s  2s
  13 Other Orbitals:
  2p  3s  3p  4s  3d  4p  5s  4d  5p  4f  5d  5f  5g
  1    4863   30000   snonh
  5So    45       743           3131        45
