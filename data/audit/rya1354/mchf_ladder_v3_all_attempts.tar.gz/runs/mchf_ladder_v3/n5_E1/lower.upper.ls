  Transition between files: 
  lower                   
  upper                   

 Z =   8 n =  5
   4  -74.56300573  2p(3)4S3.3s_5S                                    
   6  -74.50523151  2p(3)4S3.3p_5P                                    
   12679.54 CM-1      7886.72 ANGS(VAC)      7885.90 ANGS(AIR)
 E1  length:   S =  1.30687D+02   GF =  5.03338D+00   AKI =  3.59847D+07
    velocity:  S =  1.24005D+02   GF =  4.77604D+00   AKI =  3.41449D+07
