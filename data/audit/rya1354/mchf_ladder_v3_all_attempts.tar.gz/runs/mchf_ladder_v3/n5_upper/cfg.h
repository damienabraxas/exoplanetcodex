   2 Closed Shells:
  1s  2s
  13 Other Orbitals:
  2p  3s  3p  4p  4f  5p  5f  3d  4s  4d  5s  5d  5g
  1    5037   30000   snonh
  5Pe   169      6441          26635       158
