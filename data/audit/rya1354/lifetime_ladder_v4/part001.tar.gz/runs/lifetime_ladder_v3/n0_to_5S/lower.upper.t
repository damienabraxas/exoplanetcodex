 Transition between files:
 f1 = lower
 f2 = upper


 Magnetic 2**( 1)-pole transitions
 =================================

 Upper       Lower 
 Lev  J P   Lev  J P       E (Kays)         A (s-1)          gf            S
 f2  1    1 -  f1  1    2 -        2594.50 M  1.33703D-08  8.93330D-15  8.51456D-08


 Electric 2**( 2)-pole transitions
 =================================

 Upper       Lower 
 Lev  J P   Lev  J P       E (Kays)         A (s-1)          gf            S
 f2  1    1 -  f1  1    2 -        2594.50 C  2.25705D-16  1.50804D-22  5.14272D-11
                                           B  4.61399D-17  3.08282D-23  1.05130D-11


 Magnetic 2**( 3)-pole transitions
 =================================

 Upper       Lower 
 Lev  J P   Lev  J P       E (Kays)         A (s-1)          gf            S
 f2  1    1 -  f1  1    2 -        2594.50 M  3.88007D-27  2.59245D-33  3.51375D-07
