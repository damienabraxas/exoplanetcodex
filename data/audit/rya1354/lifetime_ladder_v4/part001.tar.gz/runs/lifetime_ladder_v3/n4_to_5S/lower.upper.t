 Transition between files:
 f1 = lower
 f2 = upper


 Magnetic 2**( 1)-pole transitions
 =================================

 Upper       Lower 
 Lev  J P   Lev  J P       E (Kays)         A (s-1)          gf            S
 f2  1    1 -  f1  1    2 -        2755.01 M  1.66281D-08  9.85314D-15  8.84417D-08


 Electric 2**( 2)-pole transitions
 =================================

 Upper       Lower 
 Lev  J P   Lev  J P       E (Kays)         A (s-1)          gf            S
 f2  1    1 -  f1  1    2 -        2755.01 C  6.10861D-17  3.61973D-23  1.03098D-11
                                           B  2.23839D-16  1.32638D-22  3.77785D-11


 Magnetic 2**( 3)-pole transitions
 =================================

 Upper       Lower 
 Lev  J P   Lev  J P       E (Kays)         A (s-1)          gf            S
 f2  1    1 -  f1  1    2 -        2755.01 M  1.19287D-26  7.06846D-33  7.09646D-07
