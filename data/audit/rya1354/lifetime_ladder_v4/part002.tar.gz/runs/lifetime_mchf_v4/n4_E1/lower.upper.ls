  Transition between files: 
  lower                   
  upper                   

 Z =   8 n =  4
   4  -74.88925561  2p(4)_3P2                                         
   2  -74.54937421  2p(3)4S3.3s_3S                                    
   74592.79 CM-1      1340.61 ANGS(VAC)      1340.61 ANGS(AIR)
 E1  length:   S =  1.42670D+00   GF =  3.23260D-01   AKI =  3.99915D+08
    velocity:  S =  1.63776D+00   GF =  3.71083D-01   AKI =  4.59077D+08
