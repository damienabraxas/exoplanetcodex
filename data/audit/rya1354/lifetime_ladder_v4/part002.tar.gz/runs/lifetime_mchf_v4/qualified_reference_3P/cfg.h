   2 Closed Shells:
  1s  2s
   1 Other Orbitals:
  2p
  1       3   30000   snonh
  3Pe     1         1              3         1
