   2 Closed Shells:
  1s  2s
   2 Other Orbitals:
  2p  3s
  1       8   30000   snonh
  3So     1         1              6         1
