


SHELL = /bin/sh

INSTALL = /usr/bin/install -c

BINDIR = /mnt/codex-data/codex/rya1354/evidence/fac_bootstrap_v17/unused_install_prefix/bin

TOPDIR = /mnt/codex-data/codex/rya1354/toolchains/fac-9ab6def

CC = gcc
CFLAGS = -O2 -std=gnu17 -fPIC
CPPFLAGS =  -I/mnt/codex-data/codex/rya1354/toolchains/fac-9ab6def -I/mnt/codex-data/codex/rya1354/toolchains/fac-9ab6def/faclib
LDFLAGS =  -L/mnt/codex-data/codex/rya1354/toolchains/fac-9ab6def
LIBS =  -lfac -lmlapack -lmblas -L/usr/lib/gcc/x86_64-linux-gnu/15 -L/usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu -L/usr/lib/gcc/x86_64-linux-gnu/15/../../../../lib -L/lib/x86_64-linux-gnu -L/lib/../lib -L/usr/lib/x86_64-linux-gnu -L/usr/lib/../lib -L/usr/lib/gcc/x86_64-linux-gnu/15/../../.. -L/lib -L/usr/lib -lgfortran -lm -lquadmath

ALL_CFLAGS = ${CPPFLAGS} ${CFLAGS} ${LDFLAGS} ${LIBS}

all: sfac scrm spol

sfac: 	sfac.c stoken.c ${TOPDIR}/libfac.a
	${CC} -o sfac sfac.c stoken.c ${ALL_CFLAGS}
scrm: 	scrm.c stoken.c ${TOPDIR}/libfac.a
	$(CC) -o scrm scrm.c stoken.c ${ALL_CFLAGS}
spol: 	spol.c stoken.c ${TOPDIR}/libfac.a
	$(CC) -o spol spol.c stoken.c ${ALL_CFLAGS}

install:
	${INSTALL} -d ${BINDIR}
	${INSTALL} sfac ${BINDIR}
	${INSTALL} scrm ${BINDIR}
	${INSTALL} spol ${BINDIR}

clean:
	rm -rf *.o *~ sfac scrm spol



